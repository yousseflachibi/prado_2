<?php

class Home extends BasicPage
{
	public function onLoad($param)
	{
		parent::onLoad($param);

		if(!$this->getIsPostBack())
		{
		}
	}
	public function buttonClicked($sender,$param)
    {
		//die('kjsdfh');
        // $sender refers to the button component
        $sender->Text="Hello World!";
    }
}
